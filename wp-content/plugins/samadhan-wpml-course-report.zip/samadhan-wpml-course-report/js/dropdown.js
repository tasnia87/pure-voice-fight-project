function selectGroupsDropDownCohort(){

    var $group_id=jQuery('#search_group_id').val();
    var $cohort_id=jQuery('#search_cohort_id').val();
    var $course_id=jQuery('#search_couser_id').val();

    jQuery('.loading-overlay').show();
    jQuery.ajax({
        url: wpApiSettings.root + 'cohort/v1/selectGroupsDrowDown',
        method: 'post',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', wpApiSettings.nonce);
        },
        data: {group_id:$group_id,cohort_id:$cohort_id,course_id:$course_id}
    }).done(function (response) {

        if(response.status){
            jQuery('#search_cohort_id').html(response.groupsDropdown);
            jQuery('#search_course_id').html(response.coursesDropdown);
            jQuery('.loading-overlay').hide();
        }

    }).fail(function () {

    }).always(function () {

    });
}
function selectCohortsDropDownCohort(){

    var $group_id=jQuery('#search_group_id').val();
    var $cohort_id=jQuery('#search_cohort_id').val();
    var $course_id=jQuery('#search_couser_id').val();

    jQuery('.loading-overlay').show();
    jQuery.ajax({
        url: wpApiSettings.root + 'cohort/v1/selectCohortsDrowDown',
        method: 'post',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', wpApiSettings.nonce);
        },
        data: {group_id:$group_id,cohort_id:$cohort_id,course_id:$course_id}
    }).done(function (response) {

        if(response.status){
            jQuery('#search_course_id').html(response.coursesDropdown);
            jQuery('.loading-overlay').hide();
        }

    }).fail(function () {

    }).always(function () {

    });
}