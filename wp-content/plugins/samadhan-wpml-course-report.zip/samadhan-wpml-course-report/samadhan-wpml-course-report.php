<?php
/**
 * Plugin Name:       Samadhan WPML Course Reports
 * Plugin URI:        http://samadhan.com.au
 * Description:       This plugin create WPML Course Reports.
 * Version:           4.0.4
 * Author:            Samadhan
 * Author URI:        http://samadhan.com.au
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

use Samadhan\admin_group_members;

require_once(dirname(__FILE__) . '/includes/admin_group_report.php');

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

//add_action( 'login_enqueue_scripts', 'samadhan_login_enqueue_script', 1 );
add_action('wp_enqueue_scripts', 'samadhan_login_enqueue_script', 1);

add_action('init', 'samadhan_custom_init');

//add_filter( "pmpro_require_javascript_for_checkout", "samadhan_pmpro_supress_javascript_error_for_checkout");

add_action(
    'ld_added_group_access',
    function ($user_id, $group_id) {
        update_user_meta($user_id, 'learndash_group_users_enrolled_date_' . $group_id, strtotime(date("Y-m-d")));
    },
    10,
    2
);

add_action(
    'ld_removed_group_access',
    function ($user_id, $group_id) {
        delete_user_meta($user_id, 'learndash_group_users_enrolled_date_' . $group_id);
    },
    10,
    2
);

function smdn_cohort_js_css()
{
  $ver = '1.0.0';
$path = plugins_url('js/dropdown.js', __FILE__);
wp_enqueue_script('site-admin-js', $path, array('jquery'), $ver);

wp_localize_script('dropdown-js', 'wpApiSettings', array(
    'root' => admin_url( 'admin-ajax.php' ),
'nonce' => wp_create_nonce('wp_rest'),

));

wp_enqueue_script('dropdown-js');
}


add_action('init','smdn_api_cohort_initial_load');
function smdn_api_cohort_initial_load(){
    add_action('rest_api_init','smdn_cohort_info_rest_api_init');
}
function smdn_cohort_info_rest_api_init(){

    register_rest_route('cohort/v1', '/selectGroupsDrowDown', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'smdn_select_groups_dropdown'
));
    register_rest_route('cohort/v1', '/selectCohortsDrowDown', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'smdn_select_cohorts_dropdown'
));



}


function smdn_select_groups_dropdown(){
    $get_group_id=$_POST['group_id'];
    $get_cohort_id=$_POST['cohort_id'];
    $get_course_id=$_POST['course_id'];
    $status=0;
    if(isset($get_group_id)){
        $cohorts_ids= \Samadhan\admin_group_members::get_children_groups( $get_group_id );
        $cohort_options='<option value="-1" >--All--</option>';
        foreach ($cohorts_ids as $cohort_id) {
            $cohort_options .= ' <option '.selected($cohort_id,$get_group_id,false).' value="' .$cohort_id . '">' . get_the_title($cohort_id) . '</option>';
        }

        $group_courses     = learndash_get_group_courses_list( $get_group_id );
        $course_options='<option value="-1">--All--</option>';
        foreach ($group_courses as $course_id) {
            $course_options .= ' <option '.selected($course_id,$get_course_id,false).' value="' .$course_id . '">' . get_the_title($course_id) . '</option>';
        }

        $status=1;
    }

    return rest_ensure_response(array('groupsDropdown'=>$cohort_options,'coursesDropdown'=>$course_options,'status'=>$status));
}
function smdn_select_cohorts_dropdown(){
    $get_group_id=$_POST['group_id'];
    $get_cohort_id=$_POST['cohort_id'];
    $get_course_id=$_POST['course_id'];
    $status=0;
    if(isset($get_cohort_id)){

        $group_courses     = learndash_get_group_courses_list( $get_cohort_id );
        $course_options='<option value="-1">--All--</option>';
        foreach ($group_courses as $course_id) {
            $course_options .= ' <option '.selected($get_course_id,$course_id,false).' value="' .$course_id . '">' . get_the_title($course_id) . '</option>';
        }

        $status=1;
    }

    return rest_ensure_response(array('coursesDropdown'=>$course_options,'status'=>$status));
}




function samadhan_custom_init()
{
    add_shortcode('samadhan_wpml_course_report', 'Samadhan\admin_group_members::membership_report');
    samadhan_process_report_download();
}

function samadhan_login_enqueue_script()
{
    $style_path = plugin_dir_url('/samadhan-wpml-course-report/css/login-style.css') . 'login-style.css';
    wp_enqueue_style('core', $style_path, false);
}

function samadhan_pmpro_supress_javascript_error_for_checkout()
{
    return false;
}

function samadhan_process_report_download()
{
    if (!isset($_POST['samadhan_report_type'])) return;

    $report_type = $_POST['samadhan_report_type'];

    switch ($report_type) {
        case "GROUP_ADMIN_USER_LIST":
            Samadhan\admin_group_members::group_user_download();
            break;
        default:
            echo $report_type . " is not implemented!";
            break;

    }

}



/*********************************** NO CHANGE BELOW THIS LINE ******************************************************/
