/**
 * Created by fazlur on 3/02/18.
 */

$( function() {
    $('#external_course_date' ).datepicker({
        dateFormat: "dd/mm/yy", maxDate: "0d"
    });

} );

function onDeleteClick() {
    var response =  confirm('Are you sure you want to Delete CPD Points?');
    if( response == true) {
        $('#samadhan_cpd_edit_action').val('DELETE');
    }
    return response;
}


function onAddClick() {
    var response =  confirm('Are you sure you want to Add CPD Points?');
    if( response == true) {
        $('#samadhan_cpd_edit_action').val('INSERT');
    }
    return response;
}

function onSearchClick() {
    $('#samadhan_cpd_edit_action').val('SEARCH');
    return true;
}
