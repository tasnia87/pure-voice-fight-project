/**
 * Created by fazlur on 3/02/18.
 */

$( function() {
    $('#external_course_date' ).datepicker({
        dateFormat: "dd/mm/yy", maxDate: "0d"
    });

} );

