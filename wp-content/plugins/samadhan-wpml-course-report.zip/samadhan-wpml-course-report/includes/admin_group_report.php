<?php

namespace Samadhan;

use DateTime;
use LDLMS_Transients;
use LearnDash_Settings_Section;
use WP_Query;
use WP_User_Query;

/**
 * Created by PhpStorm.
 * User: Samadhan Solution
 * Date: 12/3/17
 * Time: 12:18 PM
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Creating the widget
class admin_group_members
{
    public function __construct()
    {
    }

    public static function group_user_download()
    {
        if (isset($_POST['securityNetUsers'])) {

            if (!empty($_POST['groupName']) && $_POST['groupName'] > 0 && $_POST['cohortName'] < 0) {
                $group_id = $_POST['groupName'];
            }
            if (!empty($_POST['groupName']) && $_POST['groupName'] > 0 && $_POST['cohortName'] > 0) {
                $group_id = $_POST['cohortName'];
            }


            $selected_course_id = $_POST['courseName'];
            $userEmail = $_POST['userEmail'];
            $userEnrolledDate = strtotime($_POST['userEnrolledDate']);


            check_admin_referer('securityNet');
            $object = new admin_group_members();
            $object->process_users_list_download($group_id, $selected_course_id, $userEmail, $userEnrolledDate);
        }

    }


    public static function smdn_get_last_login_date($user_id)
    {

        $last_login = 'No login record found!';

        $last_login_epoc = get_user_meta($user_id, 'wfls-last-login', true);
        if (isset($last_login_epoc) && $last_login_epoc > 0) {
            $dt = new DateTime("@$last_login_epoc");
            $last_login = $dt->format('Y-m-d');
        } else {
            $sessions = get_user_meta($user_id, 'session_tokens');
            if (isset($sessions) && is_array($sessions)) {
                $session_items = $sessions[0];
                if (isset($session_items) && is_array($session_items)) {
                    foreach ($session_items as $item) {
                        $login_epoc = $item['login'];
                        $dt = new DateTime("@$login_epoc");
                        $last_login = $dt->format('Y-m-d');
                    }
                }
            }
        }

        if (empty($last_login)) {
            $last_login = get_user_meta($user_id, 'learndash-last-login', true);
        }

        return $last_login;
    }

    public static function get_learndash_group_users($group_id = 0)
    {
        global $wpdb;


        if ($group_id > 0) {

            $query = "SELECT distinct user_id FROM {$wpdb->prefix}usermeta where meta_key = 'learndash_group_users_$group_id' or meta_key = 'learndash_group_leader_$group_id'";
        } else {
            $query = "SELECT distinct user_id FROM {$wpdb->prefix}usermeta where meta_key like '%learndash_group_users_%' or meta_key like '%learndash_group_leader_%' ";
        }

        return $wpdb->get_results($query);

    }


    public static function smdn_get_user_email()
    {
        global $wpdb;

        //$query="SELECT distinct user_id FROM {$wpdb->prefix}usermeta where meta_key = 'learndash_group_users_$group_id' or meta_key = 'learndash_group_leader_$group_id'";

        $query = "SELECT u.ID FROM {$wpdb->prefix}users as u
        
            INNER JOIN {$wpdb->prefix}usermeta as m
           ON u.ID=m.user_id
        
         INNER JOIN {$wpdb->prefix}posts as p
         ON m.meta_value=p.ID 
        
         where m.meta_key LIKE '%learndash_group_users_%';";


        return $wpdb->get_results($query);


    }


    public static function get_group_id_by_userid($user_id)
    {
        global $wpdb;

        //$query="SELECT meta_value as group_id FROM {$wpdb->prefix}usermeta where user_id=$user_id and meta_key like '%learndash_group_users_%' or meta_key like '%learndash_group_leader_%' order by user_id desc";

        $query = "SELECT meta_value as group_id FROM {$wpdb->prefix}usermeta where user_id=$user_id and meta_key like '%learndash_group_users_%' or meta_key like '%learndash_group_leader_%' order by user_id desc ";

        return $wpdb->get_col($query);
    }

    public static function get_children_groups($group_id)
    {

        $child_groups = [];
        global $wpdb;
        $sql_str = "SELECT DISTINCT(ID) 
        FROM $wpdb->posts WHERE post_parent = $group_id AND post_type='groups' ";
        $group_ids = $wpdb->get_col($sql_str);
        if (isset($group_ids) && is_array($group_ids)) {
            $child_groups = array_merge($child_groups, $group_ids);
            foreach ($group_ids as $group_id) {
                $_child_groups = self::get_children_groups($group_id);
                if (isset($_child_groups) && is_array($_child_groups)) {
                    $child_groups = array_merge($child_groups, $_child_groups);
                }

            }
            return $child_groups;
        }
    }

    public static function get_parent_group_ids()
    {
        global $wpdb;
        if (current_user_can('administrator')) {
            $sql_str = "SELECT DISTINCT(ID) 
                    FROM $wpdb->posts
                    WHERE post_parent = 0 
                    AND post_type='groups' 
                    AND post_status='publish' ";
        }

        if (learndash_is_group_leader_user()) {
            $user_id = get_current_user_id();
            $sql_str = "  SELECT DISTINCT(ID) 
                    FROM $wpdb->postsposts  as p
                    INNER JOIN $wpdb->postsusermeta as m
                    ON p.ID=m.meta_value and meta_key like '%learndash_group_leader_%'
                    WHERE p.post_parent = 0 
                    AND p.post_type='groups' 
                    AND p.post_status='publish'
                    AND m.user_id=$user_id";

        }

        $parent_group_ids = $wpdb->get_results($sql_str);
        return $parent_group_ids;


    }


    public static function smdn_get_group_users_all_data($group_id = '', $user_email = '', $enrolled_date = '')
    {

        global $wpdb;
        $admin_Query = "SELECT user_id FROM {$wpdb->prefix}usermeta where meta_key='wp_capabilities'  and meta_value like '%administrator%'";
        $query = "SELECT distinct(ID) FROM {$wpdb->prefix}users as u
              inner join {$wpdb->prefix}usermeta as m
              on u.id=m.user_id
              inner join {$wpdb->prefix}usermeta as m2 
              on u.id=m2.user_id
              where u.ID NOT IN($admin_Query)
              ";


        if (!empty($group_id)) {
            $query .= "  and  m.meta_key like '%learndash_group_users_$group_id%'";
        }
        if (!empty($enrolled_date)) {
            $query .= "   and m2.meta_key like '%learndash_group_users_enrolled_date_$group_id%' and m2.meta_value='$enrolled_date' ";
        }
        if (!empty($user_email)) {
            $query .= "    and u.user_email='$user_email'";
        }

        return $wpdb->get_results($query);
    }


    public static function membership_report()
    {

        if (is_user_logged_in()) {


            $membership_table = self::filter_form();
            $membership_table .= '<table class="table cpd-report-table" style="font-size: 14px;">';
            if (!empty($_POST['groupName']) || !empty($_POST['userEmail']) || !empty($_POST['userEnrolledDate'])) {
                //||

                $membership_table .= '<caption><h3>List of Active Users</h3></caption>';
                $membership_table .= '<thead style="border: 1px solid #ccc;">
                                <tr style="background-color: #7B428480;color: #fff;">
                                    <th rowspan="" style="padding-left: 20px ; vertical-align: middle; border: 1px solid #ccc;">Sl No</th>
                                    <th class="a" rowspan="" style="border: 1px solid #ccc; vertical-align: middle;">User Name</th>
                                    <th rowspan="" style="border: 1px solid #ccc; vertical-align: middle;">User Email</th>                                    
                                    <th colspan="" style="border: 1px solid #ccc; vertical-align: middle;">Course Title</th>
                                    <th colspan="" style="border: 1px solid #ccc; vertical-align: middle;">Steps Completed</th>
                                    <th colspan="" style="border: 1px solid #ccc; vertical-align: middle;">Total Steps</th>
                                    <th colspan="" style="border: 1px solid #ccc; vertical-align: middle;">Course Completed</th>
                                    <th colspan="" style="padding-right: 20px;  vertical-align: middle; width: 9%; border: 1px solid #ccc;">Last Login</th>
                                  </tr>
                              </thead>';
            } else {
                $membership_table .= '<caption><h3>List of Active Users</h3></caption>';
                $membership_table .= '<thead style="border: 1px solid #ccc;">
                                <tr style="background-color: #7B428480;color: #fff;">
                                    <th rowspan="" style="padding-left: 20px ;  border: 1px solid #ccc;">Sl No</th>
                                    <th class="a" rowspan="" style="border: 1px solid #ccc; ">User Name</th>
                                    <th rowspan="" style="border: 1px solid #ccc; ">User Email</th>                                    
                                    <th colspan="" style="border: 1px solid #ccc; ">Course Title</th>
                                    <th colspan="" style="border: 1px solid #ccc; ">Steps Completed</th>
                                    <th colspan="" style="border: 1px solid #ccc; ">Total Steps</th>
                                    <th colspan="" style="border: 1px solid #ccc; ">Course Completed</th>
                                    <th colspan="" style="padding-right: 20px;  border: 1px solid #ccc;">Last Login</th>
                                  </tr>
                              </thead>';
            }
            $membership_table .= '<tbody style="border: 1px solid #ccc;">';


            $selected_course_id = $_POST['courseName'];
            $userEmail = $_POST['userEmail'];
            $userEnrolledDate = strtotime($_POST['userEnrolledDate']);

            //  $user_data = self::smdn_get_group_users_all_data($group_id, $userEmail, $userEnrolledDate);

            $sl_no = 1;
            $user_id =get_current_user_id(); ;



            $get_user_data = get_userdata($user_id);
            $course_ids = learndash_user_get_enrolled_courses($user_id, array());
            $last_login_date = self::smdn_get_last_login_date($user_id);
            $course_progress_data = get_user_meta($user_id, '_sfwd-course_progress', true);


            $steps_completed = 0;
            $course_completed = 'Not Started';
            $membership_row = '';

            if (isset($selected_course_id) && !empty($selected_course_id) && $selected_course_id > 0) {
                $include_post_types = array('sfwd-lessons', 'sfwd-topic');
                $steps_total = count(learndash_get_course_steps($selected_course_id, $include_post_types));
                if (isset($course_progress_data) && is_array($course_progress_data)) {
                    $course_progress = learndash_user_get_course_progress($user_id, $selected_course_id);
                    $course_completed = $course_progress['status'];
                    $steps_completed = $course_progress_data[$selected_course_id]['completed'];
                    if (is_null($steps_completed)) {
                        $steps_completed = 0;
                    }

                }

                $course_title = get_the_title($selected_course_id);

                $membership_table .= '<tr>
                                  <td style="padding-left: 20px;">' . $sl_no++ . '</td>' .
                    '<td>' . $get_user_data->data->display_name . '</td>
                                  <td>' . $get_user_data->data->user_email . '</td>
                                
                                  <td>' . $course_title . '</td>                   
                                  <td>' . $steps_completed . '</td>
                                  <td>' . $steps_total . '</td>
                                  <td style="text-transform: capitalize;">' . str_replace('_', ' ', $course_completed) . '</td>
                                  <td style="padding-right: 20px;">' . $last_login_date . '</td>
                                </tr>';

            } else {

                if (!empty($course_ids) && $course_ids > 0) {
                    foreach ($course_ids as $course_id) {
                        $user_email1 = $get_user_data->data->user_email;
                        
                        $user_email2 = $userEmail;
                        if ($user_email1 == $user_email2 or empty($user_email2)) {
                            // Check if user started any course
                            if ($selected_course_id == $course_id or $selected_course_id == -1 or empty($selected_course_id)) {
                                $include_post_types = array('sfwd-lessons', 'sfwd-topic');

                                $steps_total = count(learndash_get_course_steps($course_id, $include_post_types));
                                if (isset($course_progress_data) && is_array($course_progress_data)) {
                                    $course_progress = learndash_user_get_course_progress($user_id, $course_id);
                                    $course_completed = $course_progress['status'];
                                    $steps_completed = $course_progress_data[$course_id]['completed'];
                                    if (is_null($steps_completed)) {
                                        $steps_completed = 0;
                                    }
                                }

                                $course_title = get_the_title($course_id);

                                $membership_row .= '<tr>
                                  <td style="padding-left: 20px;">' . $sl_no++ . '</td>' .
                                    '<td>' . $get_user_data->data->display_name . '</td>
                                  <td>' . $get_user_data->data->user_email . '</td>
                                 
                                  <td>' . $course_title . '</td>                   
                                  <td>' . $steps_completed . '</td>
                                  <td>' . $steps_total . '</td>
                                  <td style="text-transform: capitalize;">' . str_replace('_', ' ', $course_completed) . '</td>
                                  <td style="padding-right: 20px;">' . $last_login_date . '</td>
                                </tr>';

                            }
                        }
                    }//end of loop for course
                }// end if condition
                $membership_table .= $membership_row;
            }


$membership_table .= ' </tbody> ';
$membership_table .= '</table>';
return $membership_table;
}
    }


    public static function filter_form()
    {
        smdn_cohort_js_css();



        $cohort_id = $_POST['cohortName'];
        $group_id = $_POST['groupName'];
        $selected_course_id = $_POST['courseName'];
        $userEmail = $_POST['userEmail'];
        $userEnrolledDate = $_POST['userEnrolledDate'];

        if (!empty($_POST['groupName']) && $_POST['groupName'] > 0 && $_POST['cohortName'] < 0) {
            $select_course_group_id = $_POST['groupName'];
        }
        if (!empty($_POST['groupName']) && $_POST['groupName'] > 0 && $_POST['cohortName'] > 0) {
            $select_course_group_id = $_POST['cohortName'];
        }



        $parent_group_ids = self::get_parent_group_ids();
        $total_group = count($parent_group_ids);

        $group_option = "<option value='-1'>--All--</option>";
        foreach ($parent_group_ids as $group) {
            $group_option .= "<option " . selected($group_id, $group->ID, false) . " value='$group->ID'>" . get_the_title($group->ID) . "</option>";
        }



        /*********** Cohort option **********/

        $cohort_option = "<option value='-1'>--All--</option>";
        $children_groups = self::get_children_groups($group_id);

        foreach ($children_groups as $children_group) {
            $get_child_group_name = get_the_title($children_group);
            $cohort_option .= "<option " . selected($cohort_id, $children_group, false) . " value='$children_group'>$get_child_group_name</option>";

        }

//        $course_data = get_posts(array('post_type' => 'sfwd-courses'));
//        $course_option = "<option value='-1'>All</option>";
//        foreach ($course_data as $course) {
//            $course_option .= "<option " . selected($selected_course_id, $course->ID, false) . " value='$course->ID'>$course->post_title</option>";
//        }


        //$group_courses     = learndash_get_group_courses_list( $select_course_group_id );
        $current_user = get_current_user_id();

        $group_courses=learndash_user_get_enrolled_courses($current_user);

        $course_option='<option value="-1" >--All--</option>';
        foreach ($group_courses as $course_id) {
            $course_option .= ' <option '.selected($course_id,$selected_course_id,false).' value="' .$course_id . '">' . get_the_title($course_id) . '</option>';
        }


        /*****************/

        $form_html = '<form id="cpd-point-entry" method="post" role="form">
             ' . wp_nonce_field('leader_cpd_report') . '
            <input type="hidden" name="samadhan_membership_report" value="SEARCH">
            <input type="hidden" name="samadhan_report_type" value="GROUP_ADMIN_USER_LIST">


            <table id="searchResults" class="display" cellspacing="0" width="100%" xmlns="http://www.w3.org/1999/html">
                <thead>
                <tr>';

         $form_html .= '<th style="width: 4%; text-align: center">Select Course</th>
                    <th style="width: 4%; text-align: center">User Email</th>
                    <th style="width: 4%; text-align: center">Date</th>
                    <th style="width: 1%; text-align: center ">Search</th>
                    <th style="width: 1%; text-align: center; padding-right: 20px;">Download CSV</th>
                </tr>
                </thead>
                </tbody>';


        $form_html .= ' <tr style="background-color: #7B428480;">';


        $form_html .= ' <td style="vertical-align: top; padding-left: 0px; padding-right: 0px; text-align: center">
                        <select id="search_course_id" name="courseName" style="width: 300px">
                            ' . $course_option . '
                        </select>
                    </td>


                    <td style="vertical-align: top;padding-left: 0px; padding-right: 0px; text-align: center">
                        <input type="text" class="form-control" name="userEmail" id="userEmail"
                               value="' . $userEmail . '">
                    </td>
                    <td style="vertical-align: top; padding-left: 0px; padding-right: 0px; text-align: center">
                        <input type="date" class="form-control" name="userEnrolledDate" id="userEnrolledDate"
                               value="' . $userEnrolledDate . '">
                    </td>

                    <td style="vertical-align: top; padding-left: 0px; padding-right: 0px; text-align: center">
                        <input type="submit" style="width: 100%;" class="btn btn-success btn-send"
                               id="smdn-course-report-button" name="samadhan-cpd-group-leader-search" value="Search">
                    </td>
                    <td style="vertical-align: top;; text-align: center;padding-right: 20px;">
                        ' . wp_nonce_field('securityNet') . '
                        <input style="width: 100%;" type="submit" class="btn btn-success btn-send"
                               id="smdn-course-report-button" name="securityNetUsers" value="Download CSV">

                    </td>

                </tr>

                </tbody>
            </table>
        </form><div class="loading-overlay"></div>';

        return $form_html;

    }

    public function process_users_list_download($group_id, $selected_course_id, $userEmail,$userEnrolledDate)
    {
        $user_group_name = get_the_title($group_id);
        $user_group_name = str_replace('–', ' ', $user_group_name);
        $user_group_name = str_replace('&#8211;', '-', $user_group_name);
        $user_group_name = str_replace('"', ' ', $user_group_name);
        $user_group_name = str_replace("'", ' ', $user_group_name);
        $user_group_name = str_replace(",", ' ', $user_group_name);

        $content = 'Content-Disposition: attachment; filename="' . $user_group_name . '_users_report' . '.csv"';

        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private", false);
        header("Content-Type: application/octet-stream");
        header($content);
        header("Content-Transfer-Encoding: binary");

        $csv_data = $this->get_csv_header();
        $csv_data .= $this->get_wpml_course_users_report($group_id, $selected_course_id, $userEmail,$userEnrolledDate);
        echo $csv_data;
        exit;
    }

    function get_csv_header()
    {
        return '"Sl No","User Name","User Email","Organization/Role","Course Title","Steps Completed","Total Steps","Course Completed","Last Login"' . "\n";
    }

    function get_wpml_course_users_report($group_id, $selected_course_id, $userEmail,$userEnrolledDate)
    {

        $csv_data = '';

        $user_data = self::smdn_get_group_users_all_data($group_id, $userEmail, $userEnrolledDate);
        $sl_no = 1;
        if ((is_array($user_data) && !empty($group_id)) || (is_object($user_data) && !empty($group_id))) {
            foreach ($user_data as $user) {
                $user_id = $user->ID;

                $user_group_name = '';
                if (learndash_is_admin_user($user_id)) {
                    $user_group_name = 'Administrator';
                } else if (learndash_is_group_leader_user($user_id))
                    $user_group_name = 'Group leader';
                else {
                    $user_groups = learndash_get_users_group_ids($user_id);
                    if (isset($user_groups) && is_array($user_groups)) {
                        foreach ($user_groups as $user_group) {
                            if (strlen($user_group_name) > 0)
                                $user_group_name .= ", ";
                            $user_group_name .= get_the_title($user_group);
                        }
                    }
                }

                $get_user_data = get_userdata($user_id);
                $course_ids = learndash_user_get_enrolled_courses($user_id, array());
                $last_login_date = self::smdn_get_last_login_date($user_id);
                $course_progress_data = get_user_meta($user_id, '_sfwd-course_progress', true);
                $user_group_enroll_date = get_user_meta($user_id, 'learndash_group_users_enrolled_date_' . $group_id, true);
                $user_group_enroll_date = !empty($user_group_enroll_date) ? date("Y-m-d", $user_group_enroll_date) : '00-00-00';


                $steps_completed = 0;
                $course_completed = 'Not Started';
                $membership_row = '';

                if (isset($selected_course_id) && !empty($selected_course_id) && $selected_course_id > 0 && empty($userEnrolledDate)) {
                    $include_post_types = array('sfwd-lessons', 'sfwd-topic');
                    $steps_total = count(learndash_get_course_steps($selected_course_id, $include_post_types));
                    if (isset($course_progress_data) && is_array($course_progress_data)) {
                        $course_progress = learndash_user_get_course_progress($user_id, $selected_course_id);
                        $course_completed = $course_progress['status'];
                        $steps_completed = $course_progress_data[$selected_course_id]['completed'];
                        if (is_null($steps_completed)) {
                            $steps_completed = 0;
                        }

                    }

                    $course_title = get_the_title($selected_course_id);

                    $csv_datas .= $this->to_csv_text($sl_no++) . ',';
                    $csv_datas .= $this->to_csv_text($get_user_data->data->display_name) . ',';
                    $csv_datas .= $this->to_csv_text($get_user_data->data->user_email) . ',';
                    $csv_datas .= $this->to_csv_text($user_group_name) . ',';
                    $csv_datas .= $this->to_csv_text($user_group_enroll_date) . ',';
                    $csv_datas .= $this->to_csv_text($course_title) . ',';
                    $csv_datas .= $this->to_csv_text($steps_completed) . ',';
                    $csv_datas .= $this->to_csv_text($steps_total) . ',';
                    $csv_datas .= $this->to_csv_text(str_replace('_', ' ', $course_completed)) . ',';
                    $csv_datas .= $this->to_csv_text($last_login_date) . ',';
                    $csv_datas .= "\n";
                    $isPrinted = true;


                } else {

                    if (!empty($course_ids) && $course_ids > 0) {
                        foreach ($course_ids as $course_id) {
                            $user_email1 = $get_user_data->data->user_email;
                            $user_email2 = $userEmail;
                            if ($user_email1 == $user_email2 or empty($user_email2)) {
                                // Check if user started any course
                                if ($selected_course_id == $course_id or $selected_course_id == -1 or empty($selected_course_id)) {
                                    $include_post_types = array('sfwd-lessons', 'sfwd-topic');

                                    $steps_total = count(learndash_get_course_steps($course_id, $include_post_types));
                                    if (isset($course_progress_data) && is_array($course_progress_data)) {
                                        $course_progress = learndash_user_get_course_progress($user_id, $course_id);
                                        $course_completed = $course_progress['status'];
                                        $steps_completed = $course_progress_data[$course_id]['completed'];
                                        if (is_null($steps_completed)) {
                                            $steps_completed = 0;
                                        }
                                    }

                                    $course_title = get_the_title($course_id);

                                    $csv_datas .= $this->to_csv_text($sl_no++) . ',';
                                    $csv_datas .= $this->to_csv_text($get_user_data->data->display_name) . ',';
                                    $csv_datas .= $this->to_csv_text($get_user_data->data->user_email) . ',';
                                    $csv_datas .= $this->to_csv_text($user_group_name) . ',';
                                    $csv_datas .= $this->to_csv_text($user_group_enroll_date) . ',';
                                    $csv_datas .= $this->to_csv_text($course_title) . ',';
                                    $csv_datas .= $this->to_csv_text($steps_completed) . ',';
                                    $csv_datas .= $this->to_csv_text($steps_total) . ',';
                                    $csv_datas .= $this->to_csv_text(str_replace('_', ' ', $course_completed)) . ',';
                                    $csv_datas .= $this->to_csv_text($last_login_date) . ',';
                                    $csv_datas .= "\n";
                                    $isPrinted = true;

                                }
                            }
                        }//end of loop for course
                    }// end if condition

                }

                $csv_data .= $csv_datas;
            } //end foreach all users
        } //end if condition for all users





        return $csv_data;


    }

    function to_csv_text($text_item)
    {
        $text_item = str_replace('–', ' ', $text_item);
        $text_item = str_replace('&#8211;', '-', $text_item);
        $text_item = str_replace('"', ' ', $text_item);
        $text_item = str_replace("'", ' ', $text_item);
        $text_item = str_replace(",", ', ', $text_item);
        return '"' . $text_item . '"';
    }

} // Class  ends here


function smdn_learndash_get_groups_users($group_id = 0, $user_data = 0, $bypass_transient = false)
{

    $group_id = absint($group_id);
    if (!empty($group_id)) {
        $transient_key = 'learndash_group_leaders_' . $group_id;

        if (!$bypass_transient) {
            $group_user_objects = LDLMS_Transients::get($transient_key);
        } else {
            $group_user_objects = false;
        }
        if (false === $group_user_objects) {

            $user_query_args = array(
                'orderby' => 'display_name',
                'role__not_in' => 'administrator',
                'order' => 'ASC',
                'meta_query' => array(
                    array(
                        'key' => 'learndash_group_users_' . intval($group_id),
                        'value' => intval($group_id),
                        'compare' => '=',
                        'type' => 'NUMERIC',
                    ),
                ),
            );
            if (isset($user_data) && !empty($user_data)) {
                $user_query_args = array('search' => $user_data, 'role__not_in' => 'administrator');
            }

            $user_query = new WP_User_Query($user_query_args);
            if (isset($user_query->results)) {
                $group_user_objects = $user_query->results;
            } else {
                $group_user_objects = array();
            }

            if (!$bypass_transient) {
                LDLMS_Transients::set($transient_key, $group_user_objects, MINUTE_IN_SECONDS);
            }
        }

        return $group_user_objects;
    }
}